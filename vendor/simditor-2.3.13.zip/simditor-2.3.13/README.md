### This project is no longer maintained

---

Simditor is a browser-based WYSIWYG text editor.

It is used by [Tower](http://tower.im) -- a popular project management web application.

Supported Browsers: IE10+、Chrome、Firefox、Safari.
* [Download Zip](https://github.com/mycolorway/simditor/releases)
* Install with npm: $ npm install simditor</li>
* Install with bower: $ bower install simditor</li>

Demo and docs can be found [here](http://simditor.tower.im/).
